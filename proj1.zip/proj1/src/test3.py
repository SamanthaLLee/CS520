count = 0

def inc():
    global count
    count += 1